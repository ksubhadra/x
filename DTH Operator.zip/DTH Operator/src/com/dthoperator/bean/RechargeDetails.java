/*******Author Name: Subhadra Kaligotla Emp Id : 150751 Date: 05/07/2018 ******/
//Purpose: To provide getter and setter for recharge details 

package com.dthoperator.bean;

public class RechargeDetails {
	String dthOperator;
	int consumerNo;
	String rechargePlan;
	int amount;
	int transactionID;
	
	//Default Constructor
	public RechargeDetails(){
		
	}
	
	//Initializing instance variables
	public RechargeDetails(String dthOperator, int consumerNo, String rechargePlan, int amount, int transactionID) 
	{
		super();
		this.dthOperator = dthOperator;
		this.consumerNo = consumerNo;
		this.rechargePlan = rechargePlan;
		this.amount = amount;
		this.transactionID = transactionID;
	}
    
	//Getter for DthOperator
	public String getDthOperator() 
	{
		return dthOperator;
	}
    
	//Setter for DthOperator
	public void setDthOperator(String dthOperator) 
	{
		this.dthOperator = dthOperator;
	}
    
	//Getter for ConsumerNo
	public int getConsumerNo() 
	{
		return consumerNo;
	}
    
	//Setter for ConsumerNo
	public void setConsumerNo(int consumerNo) 
	{
		this.consumerNo = consumerNo;
	}

	//Getter for RechargePlan
	public String getRechargePlan() 
	{
		return rechargePlan;
	}

	//Setter for RechargePlan 
	public void setRechargePlan(String rechargePlan) 
	{
		this.rechargePlan = rechargePlan;
	}

	//Getter for Amount
	public int getAmount() 
	{
		return amount;
	}

	//Setter for Amount
	public void setAmount(int amount) 
	{
		this.amount = amount;
	}

	//Getter for TransactionID
	public int getTransactionID() 
	{	
		return transactionID;
	}

	//Setter for TransactionID
	public void setTransactionID(int transactionID)
	{
		this.transactionID = transactionID;
	}

	//Display recharge details
	@Override
	public String toString() 
	{
		return "RechargeDetails [dthOperator=" + dthOperator + ", consumerNo=" + consumerNo + ", rechargePlan="
				+ rechargePlan + ", amount=" + amount + ", transactionID=" + transactionID + "]";
	}

}
